<!DOCTYPE html>
<html>
  <head>
    <base href="<?php echo base_url();?>"/>
    <meta charset="utf-8">
    <title>404 - Halaman tidak ditemukan</title>
		<link rel="icon" type="image/png" href="assets/error-404.png">
  </head>
  <body>
<center>
		<br><br><br>

          <img src="assets/error-404.png" alt="" />

<br><br>
          <div class="error-text">
          	<span>HALAMAN YANG ANDA MINTA</span>
          	<span class="large-text">TIDAK DAPAT DITEMUKAN</span>
          </div><br>

          	<a class="back-home" href="<?php echo base_url();?>">> B E R A N D A < </a>
</center>
  </body>
</html>
